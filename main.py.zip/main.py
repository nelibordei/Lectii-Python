r = 10 # raza bazei
H = 50 # inaltimea cilindrului
Pi = 3.14 # declaram constanta Pi

volum = Pi * r**2 * H

print(f"Volumul cilindrului este: {volum} cm3")
